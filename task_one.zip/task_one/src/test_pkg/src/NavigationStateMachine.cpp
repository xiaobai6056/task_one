#include "NavigationStateMachine.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <move_base_msgs/MoveBaseActionResult.h> 

NavigationStateMachine::NavigationStateMachine(ros::NodeHandle& nh) 
    : nh_(nh), 
      current_state_(RobotState::INIT),
      qr_received_(false),
      object_received_(false),
      simulation_received_(false),
      traffic_received_(false),
      navigation_done_(false) {
    
    // 初始化发布器和订阅器
    goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1);
    tts_publisher_ = nh_.advertise<std_msgs::String>("/tts", 1);
    
    // 初始化订阅器 - 用于接收模拟的识别结果
    qr_sub_ = nh_.subscribe("/demo/qr_result", 1, &NavigationStateMachine::qrCallback, this);
    object_sub_ = nh_.subscribe("/demo/object_result", 1, &NavigationStateMachine::objectCallback, this);
    simulation_sub_ = nh_.subscribe("/demo/simulation_result", 1, &NavigationStateMachine::simulationCallback, this);
    traffic_sub_=nh.subscribe("/demo/traffic_result",1,&NavigationStateMachine::trafficCallback, this);
    nav_result_sub_ = nh_.subscribe("/move_base/result", 1, &NavigationStateMachine::navResultCallback, this);
    
    // 加载导航点
    loadNavigationPoints();
    
    ROS_INFO("Navigation State Machine Demo Initialized");
}

void NavigationStateMachine::execute() {
    switch(current_state_) {
        case RobotState::INIT: handleInitState(); break;
        case RobotState::MOVE_TO_QR_ZONE: handleMoveToQRZone(); break;
        case RobotState::WAIT_FOR_QR: handleWaitForQR(); break;
        case RobotState::MOVE_TO_PICK_ZONE: handleMoveToPickZone(); break;
        case RobotState::WAIT_FOR_OBJECT: handleWaitForObject(); break;
        case RobotState::MOVE_TO_WAIT_ZONE: handleMoveToWaitZone(); break;
        case RobotState::WAIT_FOR_SIMULATION: handleWaitForSimulation(); break;
        case RobotState::MOVE_TO_TRAFFIC_ZONE: handleMoveToTrafficZone();break;
        case RobotState::WAIT_FOR_TRAFFIC: handleWaitForTraffic();break;
        case RobotState::MOVE_TO_FINISH: handleMoveToFinish(); break;
        case RobotState::TASK_COMPLETE: handleTaskComplete(); break;
        case RobotState::ERROR: handleErrorState(); break;
    }
}

// ========== 新的状态处理函数 ==========

void NavigationStateMachine::handleInitState() {
    ROS_INFO("[INIT] 机器人初始化");
    speak("机器人准备就绪，开始执行任务");
    setState(RobotState::MOVE_TO_QR_ZONE);
}

void NavigationStateMachine::handleMoveToQRZone() {
    ROS_INFO("[MOVE_TO_QR_ZONE] 前往二维码区域");
    speak("正在前往二维码区域");
    sendNavigationGoal("qr_zone");
    setState(RobotState::WAIT_FOR_QR);
}

void NavigationStateMachine::handleWaitForQR() {
    if (qr_received_) {
        ROS_INFO("[WAIT_FOR_QR] 收到二维码识别结果: %s", current_task_.c_str());
        speak("本次采购任务为" + current_task_);
        qr_received_ = false; // 重置标志
        setState(RobotState::MOVE_TO_PICK_ZONE);
    } else {
        ROS_INFO_THROTTLE(5, "[WAIT_FOR_QR] 等待二维码识别结果...");
    }
}

void NavigationStateMachine::handleMoveToPickZone() {
    ROS_INFO("[MOVE_TO_PICK_ZONE] 前往拣货区");
    speak("正在前往拣货区");
    sendNavigationGoal("pick_zone");
    setState(RobotState::WAIT_FOR_OBJECT);
}

void NavigationStateMachine::handleWaitForObject() {
    if (object_received_) {
        ROS_INFO("[WAIT_FOR_OBJECT] 收到物体识别结果: %s", picked_object_.c_str());
        speak("我已取到" + picked_object_);
        object_received_ = false; // 重置标志
        setState(RobotState::MOVE_TO_WAIT_ZONE);
    } else {
        ROS_INFO_THROTTLE(5, "[WAIT_FOR_OBJECT] 等待物体识别结果...");
    }
}

void NavigationStateMachine::handleMoveToWaitZone() {
    ROS_INFO("[MOVE_TO_WAIT_ZONE] 前往等待区");
    speak("正在前往等待区，等待仿真任务完成");
    sendNavigationGoal("wait_zone");
    setState(RobotState::WAIT_FOR_SIMULATION);
}

void NavigationStateMachine::handleWaitForSimulation() {
    if (simulation_received_) {
        ROS_INFO("[WAIT_FOR_SIMULATION] 收到仿真结果: %s", simulation_result_.c_str());
        speak("仿真任务已完成，目标货物位于" + simulation_result_ + "房间");
        simulation_received_ = false; // 重置标志
        setState(RobotState::MOVE_TO_TRAFFIC_ZONE);
    } else {
        ROS_INFO_THROTTLE(5, "[WAIT_FOR_SIMULATION] 等待仿真任务完成...");
    }
}

void NavigationStateMachine::handleMoveToTrafficZone() {
    ROS_INFO("[MOVE_TO_TRAFFIC_ZONE] 前往路牌识别区");
    speak("正在前往路牌识别区");
    sendNavigationGoal("traffic_zone");
    setState(RobotState::WAIT_FOR_TRAFFIC);
}

void NavigationStateMachine::handleWaitForTraffic() {
    if (traffic_received_) {
        ROS_INFO("[WAIT_FOR_TRAFFIC] 收到路牌识别结果: %s", traffic_result_.c_str());
        speak("路口" + traffic_result_ + "可通过");
        traffic_received_ = false; // 重置标志
        setState(RobotState::MOVE_TO_FINISH);
    } else {
        ROS_INFO_THROTTLE(5, "[WAIT_FOR_TRAFFIC] 等待路牌识别结果...");
    }
}

void NavigationStateMachine::handleMoveToFinish() {
    ROS_INFO("[MOVE_TO_FINISH] 前往终点");
    speak("正在前往终点");
    sendNavigationGoal("finish_zone");
    setState(RobotState::TASK_COMPLETE);
}

void NavigationStateMachine::handleTaskComplete() {
    ROS_INFO("[TASK_COMPLETE] 任务完成");
    speak("我已完成货物采购任务，本次采购货物为" + picked_object_ + "，总计花费15元，需找零5元");
    ROS_INFO("=== 演示任务完成 ===");
}

void NavigationStateMachine::handleErrorState() {
    ROS_ERROR("[ERROR] 进入错误状态");
    speak("系统出现错误，请检查");
    ros::Duration(2.0).sleep();
    setState(RobotState::INIT);
}

// ========== 旧的状态函数（废弃）==========

void NavigationStateMachine::handleQRRecognition() {
    ROS_WARN("handleQRRecognition is deprecated, use handleWaitForQR instead");
}

void NavigationStateMachine::handleObjectRecognition() {
    ROS_WARN("handleObjectRecognition is deprecated, use handleWaitForObject instead");
}

void NavigationStateMachine::handlePickObject() {
    ROS_WARN("handlePickObject not implemented in demo version");
}

void NavigationStateMachine::handleSimulationTask() {
    ROS_WARN("handleSimulationTask is deprecated, use handleWaitForSimulation instead");
}

void NavigationStateMachine::handleTrafficSignRecognition() {
    ROS_WARN("handleTrafficSignRecognition not implemented in demo version");
}

// ========== 回调函数 ==========

void NavigationStateMachine::qrCallback(const std_msgs::String::ConstPtr& msg) {
    current_task_ = msg->data;
    qr_received_ = true;
    ROS_INFO("收到二维码识别结果: %s", current_task_.c_str());
}

void NavigationStateMachine::objectCallback(const std_msgs::String::ConstPtr& msg) {
    picked_object_ = msg->data;
    object_received_ = true;
    ROS_INFO("收到物体识别结果: %s", picked_object_.c_str());
}

void NavigationStateMachine::simulationCallback(const std_msgs::String::ConstPtr& msg) {
    simulation_result_ = msg->data;
    simulation_received_ = true;
    ROS_INFO("收到仿真结果: %s", simulation_result_.c_str());
}

void NavigationStateMachine::trafficCallback(const std_msgs::String::ConstPtr& msg) {
    traffic_result_ = msg->data;
    traffic_received_ = true;
    ROS_INFO("收到路牌识别结果: %s", traffic_result_.c_str());
}


void NavigationStateMachine::navResultCallback(const move_base_msgs::MoveBaseActionResult::ConstPtr& msg) {
    if (msg->status.status == actionlib_msgs::GoalStatus::SUCCEEDED) {
        navigation_done_ = true;
        ROS_INFO("导航目标已完成");
    } else if (msg->status.status == actionlib_msgs::GoalStatus::ABORTED) {
        ROS_ERROR("导航目标失败");
        setState(RobotState::ERROR);
    }
}

// ========== 工具函数 ==========

void NavigationStateMachine::speak(const std::string& text) {
    std_msgs::String msg;
    msg.data = text;
    tts_publisher_.publish(msg);
    ROS_INFO("语音播报: %s", text.c_str());
}

void NavigationStateMachine::sendNavigationGoal(const std::string& point_name) {
    auto it = navigation_points_.find(point_name);
    if (it != navigation_points_.end()) {
        goal_pub_.publish(it->second);
        navigation_done_ = false;
        ROS_INFO("发送导航目标: %s", point_name.c_str());
    } else {
        ROS_ERROR("未知的导航点: %s", point_name.c_str());
    }
}

void NavigationStateMachine::setState(RobotState new_state) {
    ROS_INFO("状态转换: %d -> %d", 
             static_cast<int>(current_state_), 
             static_cast<int>(new_state));
    current_state_ = new_state;
}

void NavigationStateMachine::loadNavigationPoints() {
    navigation_points_["qr_zone"] = createPose(1.4, 1.1, 3.14);
    navigation_points_["pick_zone"] = createPose(1.75, 5.57, 1.57);
    navigation_points_["wait_zone"] = createPose(1.75, 5.57, 0.0);
    navigation_points_["traffic_zone"] = createPose(4.9, 6.4, 1.57); 
    navigation_points_["finish_zone"] = createPose(4.9, 0.4, -1.57);
    ROS_INFO("加载了 %zu 个导航点", navigation_points_.size());
}

geometry_msgs::PoseStamped NavigationStateMachine::createPose(double x, double y, double yaw) {
    geometry_msgs::PoseStamped pose;
    pose.header.frame_id = "map";
    pose.header.stamp = ros::Time::now();
    pose.pose.position.x = x;
    pose.pose.position.y = y;
    pose.pose.position.z = 0.0;
    
    tf2::Quaternion q;
    q.setRPY(0, 0, yaw);
    pose.pose.orientation = tf2::toMsg(q);
    
    return pose;
}