#ifndef NAVIGATION_STATE_MACHINE_H
#define NAVIGATION_STATE_MACHINE_H

#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <std_msgs/String.h>
#include <actionlib_msgs/GoalStatusArray.h>
#include <move_base_msgs/MoveBaseActionResult.h> 
#include <map>
#include <string>

enum class RobotState {
    // INIT, 
    // MOVE_TO_QR_ZONE,
    // QR_RECOGNITION,
    // MOVE_TO_PICK_ZONE,
    // OBJECT_RECOGNITION,
    // PICK_OBJECT,
    // MOVE_TO_WAIT_ZONE,
    // SIMULATION_TASK,
    // MOVE_TO_TRAFFIC_ZONE,
    // TRAFFIC_SIGN_RECOGNITION,
    // MOVE_TO_FINISH,
    // TASK_COMPLETE,
    // ERROR
    INIT,                   // 初始化
    MOVE_TO_QR_ZONE,        // 移动到二维码区域
    WAIT_FOR_QR,            // 等待二维码识别
    MOVE_TO_PICK_ZONE,      // 移动到拣货区
    WAIT_FOR_OBJECT,        // 等待物体识别
    MOVE_TO_WAIT_ZONE,      // 移动到等待区
    WAIT_FOR_SIMULATION,    // 等待仿真完成
    MOVE_TO_TRAFFIC_ZONE,   //移动到路牌识别
    WAIT_FOR_TRAFFIC,       //等待路牌识别
    MOVE_TO_FINISH,         // 移动到终点
    TASK_COMPLETE,          // 任务完成
    ERROR                   // 错误状态
};

class NavigationStateMachine {
public:
    NavigationStateMachine(ros::NodeHandle& nh);
    void execute();
    
private:
   private:
    // 新的状态处理函数
    void handleInitState();
    void handleMoveToQRZone();
    void handleWaitForQR();
    void handleMoveToPickZone();
    void handleWaitForObject();
    void handleMoveToWaitZone();
    void handleWaitForSimulation();
    void handleMoveToTrafficZone();
    void handleWaitForTraffic();
    void handleMoveToFinish();
    void handleTaskComplete();
    void handleErrorState();
    
    // 旧的状态处理函数（保留但标记为废弃）
    void handleQRRecognition();
    void handleObjectRecognition();
    void handlePickObject();
    void handleSimulationTask();
    
    void handleTrafficSignRecognition();
    
    // 工具函数
    void speak(const std::string& text);
    void sendNavigationGoal(const std::string& point_name);
    void setState(RobotState new_state);
    geometry_msgs::PoseStamped createPose(double x, double y, double yaw);
    void loadNavigationPoints();
    
    // 回调函数
    void qrCallback(const std_msgs::String::ConstPtr& msg);
    void objectCallback(const std_msgs::String::ConstPtr& msg);
    void simulationCallback(const std_msgs::String::ConstPtr& msg);
    void navResultCallback(const move_base_msgs::MoveBaseActionResult::ConstPtr& msg);
    void trafficCallback(const std_msgs::String::ConstPtr& msg);
    
    // 成员变量
    RobotState current_state_;
    ros::NodeHandle nh_;
    
    // ROS 通信
    // ros::Publisher goal_pub_;
    // ros::Subscriber result_sub_;
    // ros::Publisher tts_publisher_;
    // ros::ServiceClient qr_client_;
    // ros::ServiceClient object_client_;
    // ros::ServiceClient traffic_client_;

      // ROS 通信
    ros::Publisher goal_pub_;
    ros::Publisher tts_publisher_;
    ros::Subscriber qr_sub_;
    ros::Subscriber object_sub_;
    ros::Subscriber simulation_sub_;
    ros::Subscriber traffic_sub_;
    ros::Subscriber nav_result_sub_;
    
    
    // 任务数据
    std::string current_task_;
    std::string picked_object_;
    std::string simulation_result_;
    std::string traffic_result_;
    std::string passable_intersection_;
    double total_cost_;
    
    // 导航点配置
    std::map<std::string, geometry_msgs::PoseStamped> navigation_points_;

     // 状态标志
    bool qr_received_;
    bool object_received_;
    bool simulation_received_;
    bool traffic_received_;
    bool navigation_done_;
};

#endif