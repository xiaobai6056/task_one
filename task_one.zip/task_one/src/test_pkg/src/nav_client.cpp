#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <termios.h>
#include <unistd.h>
#include <chrono>

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

// 计时器类
class Timer {
private:
    std::chrono::steady_clock::time_point start_time;
    std::chrono::steady_clock::time_point end_time;
    bool running;
    
public:
    Timer() : running(false) {}
    
    void start() {
        start_time = std::chrono::steady_clock::now();
        running = true;
    }
    
    void stop() {
        if (running) {
            end_time = std::chrono::steady_clock::now();
            running = false;
        }
    }
    
    double getElapsedSeconds() const {
        if (running) {
            auto current = std::chrono::steady_clock::now();
            return std::chrono::duration<double>(current - start_time).count();
        } else {
            return std::chrono::duration<double>(end_time - start_time).count();
        }
    }
    
    std::string getFormattedTime() const {
        double seconds = getElapsedSeconds();
        int minutes = static_cast<int>(seconds) / 60;
        int secs = static_cast<int>(seconds) % 60;
        int millis = static_cast<int>((seconds - static_cast<int>(seconds)) * 1000);
        
        std::stringstream ss;
        ss << std::setfill('0') << std::setw(2) << minutes << ":"
           << std::setfill('0') << std::setw(2) << secs << "."
           << std::setfill('0') << std::setw(3) << millis;
        return ss.str();
    }
    
    bool isRunning() const { return running; }
};

void setNonBlockingInput(bool nonBlocking) {
    static struct termios oldt, newt;
    
    if (nonBlocking) {
        tcgetattr(STDIN_FILENO, &oldt);
        newt = oldt;
        newt.c_lflag &= ~(ICANON | ECHO);
        tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    } else {
        tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    }
}

bool checkForCancel() {
    struct timeval tv = {0, 0};
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    
    int ret = select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv);
    
    if (ret > 0) {
        char c;
        if (read(STDIN_FILENO, &c, 1) == 1) {
            return (c == 'c' || c == 'C');
        }
    }
    return false;
}

char getSingleCharInput() {
    struct timeval tv = {0, 0};
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    
    int ret = select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv);
    
    if (ret > 0) {
        char c;
        if (read(STDIN_FILENO, &c, 1) == 1) {
            return c;
        }
    }
    return 0;
}

// 从四元数获取偏航角
double getYawFromQuaternion(const geometry_msgs::Quaternion& quat)
{
    tf2::Quaternion q(quat.x, quat.y, quat.z, quat.w);
    tf2::Matrix3x3 m(q);
    double roll, pitch, yaw;
    m.getRPY(roll, pitch, yaw);
    return yaw;
}

// 计算两点之间的距离
double calculateDistance(double x1, double y1, double x2, double y2)
{
    return std::sqrt(std::pow(x2 - x1, 2) + std::pow(y2 - y1, 2));
}

// 显示核心导航信息（带计时）
void displayNavigationInfo(const move_base_msgs::MoveBaseFeedbackConstPtr& feedback, 
                          double target_x, double target_y, const Timer& timer)
{
    if (!feedback) return;
    
    // 获取当前位置和朝向
    double current_x = feedback->base_position.pose.position.x;
    double current_y = feedback->base_position.pose.position.y;
    double current_yaw = getYawFromQuaternion(feedback->base_position.pose.orientation);
    double distance_to_goal = calculateDistance(current_x, current_y, target_x, target_y);
    
    std::cout << "\033[2K\r"; // 清空当前行
    ROS_INFO("当前位置: (%.2f, %.2f)", current_x, current_y);
    ROS_INFO("当前朝向: %.1f°", current_yaw * 180/M_PI);
    ROS_INFO("目标位置: (%.2f, %.2f)", target_x, target_y);
    ROS_INFO("剩余距离: %.2f米", distance_to_goal);
    ROS_INFO("已用时间: %s", timer.getFormattedTime().c_str());
    // 移动光标向上4行以便下次更新
    std::cout << "\033[5A";
}

// 发送导航目标
bool sendNavigationGoal(MoveBaseClient& ac, double x, double y, double yaw_degrees, const std::string& goal_name)
{
    // 将角度转换为四元数
    double yaw_rad = yaw_degrees * M_PI / 180.0;
    
    move_base_msgs::MoveBaseGoal goal;
    goal.target_pose.header.frame_id = "map";
    goal.target_pose.header.stamp = ros::Time::now();
    
    goal.target_pose.pose.position.x = x;
    goal.target_pose.pose.position.y = y;
    goal.target_pose.pose.position.z = 0.0;
    
    // 将偏航角转换为四元数
    goal.target_pose.pose.orientation.x = 0.0;
    goal.target_pose.pose.orientation.y = 0.0;
    goal.target_pose.pose.orientation.z = sin(yaw_rad / 2);
    goal.target_pose.pose.orientation.w = cos(yaw_rad / 2);
    
    ROS_INFO("发送%s: x=%.2f, y=%.2f, yaw=%.1f°", goal_name.c_str(), x, y, yaw_degrees);
    
    // 创建计时器
    Timer timer;
    timer.start();
    
    // 发送目标并注册feedback回调
    ac.sendGoal(goal, 
               actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction>::SimpleDoneCallback(),
               actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction>::SimpleActiveCallback(),
               boost::bind(&displayNavigationInfo, _1, x, y, timer));
    
    std::cout << "\n导航开始... (输入 'c' 取消)" << std::endl;
    std::cout << "==========================================" << std::endl;
    
    // 主等待循环
    bool finished = false;
    bool cancelled = false;
    ros::Rate loop_rate(10);
    setNonBlockingInput(true);
    
    while(!finished && ros::ok()) {
        // 检查是否完成
        finished = ac.waitForResult(ros::Duration(0.05));
        
        if(checkForCancel()) {
            ac.cancelGoal();
            timer.stop();
            ROS_INFO("目标已取消");
            ROS_INFO("本次导航用时: %s", timer.getFormattedTime().c_str());
            cancelled = true;
            break;
        }
        
        loop_rate.sleep();
    }
    
    // 清理显示
    std::cout << "\033[5B" << std::endl;
    setNonBlockingInput(false);
    
    if(finished && !cancelled) {
        timer.stop();
        if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED) {
            ROS_INFO("任务完成!");
            ROS_INFO("总用时: %s", timer.getFormattedTime().c_str());
            return true;
        } else {
            ROS_WARN("任务失败: %s", ac.getState().toString().c_str());
            ROS_INFO("用时: %s", timer.getFormattedTime().c_str());
            return false;
        }
    }
    
    return cancelled;
}

int main(int argc, char** argv)
{   
    setlocale(LC_ALL,"");
    ros::init(argc, argv, "simple_goal_sender");
    
    MoveBaseClient ac("move_base", true);
    
    // 等待action server
    if(!ac.waitForServer(ros::Duration(5.0))) {
        ROS_ERROR("无法连接到move_base action server");
        return 1;
    }
    ROS_INFO("已连接到move_base action server");
    
    // 定义预设目标点
    struct PresetGoal {
        double x, y, yaw;
        std::string name;
    };
    
    std::vector<PresetGoal> preset_goals = {
        {0.0, 0.0, 0.0, "起点"},    // 按1
        {3.0, 4.0, 0.0, "终点"}     // 按2
    };
    
    setNonBlockingInput(true);
    
    while(ros::ok()) {
        std::cout << "\n=== 导航目标选择 ===" << std::endl;
        std::cout << "1 - 发送起点 (0, 0, 0°)" << std::endl;
        std::cout << "2 - 发送终点 (3, 4, 0°)" << std::endl;
        std::cout << "q - 退出程序" << std::endl;
        std::cout << "请选择: ";
        
        char choice = 0;
        while(choice == 0 && ros::ok()) {
            choice = getSingleCharInput();
            ros::Duration(0.1).sleep();
        }
        
        if (choice == 'q' || choice == 'Q') {
            ROS_INFO("退出程序");
            break;
        }
        else if (choice == '1') {
            std::cout << "\n发送起点..." << std::endl;
            sendNavigationGoal(ac, preset_goals[0].x, preset_goals[0].y, preset_goals[0].yaw, preset_goals[0].name);
        }
        else if (choice == '2') {
            std::cout << "\n发送终点..." << std::endl;
            sendNavigationGoal(ac, preset_goals[1].x, preset_goals[1].y, preset_goals[1].yaw, preset_goals[1].name);
        }
        else {
            std::cout << "\n无效选择，请重新输入" << std::endl;
        }
        
        // 短暂暂停，避免过于频繁的循环
        ros::Duration(0.5).sleep();
    }
    
    setNonBlockingInput(false);
    return 0;
}