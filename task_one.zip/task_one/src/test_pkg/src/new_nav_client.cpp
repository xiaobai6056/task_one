#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <termios.h>
#include <unistd.h>
#include <chrono>

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

// 计时器类
class Timer {
private:
    std::chrono::steady_clock::time_point start_time;
    std::chrono::steady_clock::time_point end_time;
    bool running;
    
public:
    Timer() : running(false) {}
    
    void start() {
        start_time = std::chrono::steady_clock::now();
        running = true;
    }
    
    void stop() {
        if (running) {
            end_time = std::chrono::steady_clock::now();
            running = false;
        }
    }
    
    double getElapsedSeconds() const {
        if (running) {
            auto current = std::chrono::steady_clock::now();
            return std::chrono::duration<double>(current - start_time).count();
        } else {
            return std::chrono::duration<double>(end_time - start_time).count();
        }
    }
    
    std::string getFormattedTime() const {
        double seconds = getElapsedSeconds();
        int minutes = static_cast<int>(seconds) / 60;
        int secs = static_cast<int>(seconds) % 60;
        int millis = static_cast<int>((seconds - static_cast<int>(seconds)) * 1000);
        
        std::stringstream ss;
        ss << std::setfill('0') << std::setw(2) << minutes << ":"
           << std::setfill('0') << std::setw(2) << secs << "."
           << std::setfill('0') << std::setw(3) << millis;
        return ss.str();
    }
    
    bool isRunning() const { return running; }
};

class NavigationManager {
private:
    ros::NodeHandle nh_;
    MoveBaseClient ac_;
    ros::Publisher initial_pose_pub_;
    
    // 将输入检查函数移到类内部
    bool checkForCancel() {
        struct timeval tv = {0, 0};
        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(STDIN_FILENO, &fds);
        
        int ret = select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv);
        
        if (ret > 0) {
            char c;
            if (read(STDIN_FILENO, &c, 1) == 1) {
                return (c == 'c' || c == 'C');
            }
        }
        return false;
    }
    
public:
    NavigationManager() : ac_("move_base", true) {
        initial_pose_pub_ = nh_.advertise<geometry_msgs::PoseWithCovarianceStamped>("/initialpose", 1);
        
        // 等待action server
        if(!ac_.waitForServer(ros::Duration(5.0))) {
            ROS_ERROR("无法连接到move_base action server");
        } else {
            ROS_INFO("已连接到move_base action server");
        }
    }
    
    // 传送功能（类似2D Pose Estimate）
    bool teleportToStart(double x, double y, double yaw_degrees, const std::string& location_name) {
        geometry_msgs::PoseWithCovarianceStamped initial_pose;
        initial_pose.header.frame_id = "map";
        initial_pose.header.stamp = ros::Time::now();
        
        double yaw_rad = yaw_degrees * M_PI / 180.0;
        
        // 设置位置
        initial_pose.pose.pose.position.x = x;
        initial_pose.pose.pose.position.y = y;
        initial_pose.pose.pose.position.z = 0.0;
        
        // 设置朝向
        initial_pose.pose.pose.orientation.x = 0.0;
        initial_pose.pose.pose.orientation.y = 0.0;
        initial_pose.pose.pose.orientation.z = sin(yaw_rad / 2);
        initial_pose.pose.pose.orientation.w = cos(yaw_rad / 2);
        
        // 设置协方差（较小的不确定性）
        for (int i = 0; i < 36; i++) {
            initial_pose.pose.covariance[i] = 0.0;
        }
        initial_pose.pose.covariance[0] = 0.25;  // x方差
        initial_pose.pose.covariance[7] = 0.25;  // y方差
        initial_pose.pose.covariance[35] = 0.068; // yaw方差
        
        ROS_INFO("传送至%s: x=%.2f, y=%.2f, yaw=%.1f°", location_name.c_str(), x, y, yaw_degrees);
        
        // 发布初始位姿
        initial_pose_pub_.publish(initial_pose);
        
        // 等待发布完成
        ros::Duration(0.5).sleep();
        
        ROS_INFO("传送完成！机器人已位于%s", location_name.c_str());
        return true;
    }
    
    // 导航功能
    bool navigateToGoal(double x, double y, double yaw_degrees, const std::string& goal_name) {
        if (!ac_.isServerConnected()) {
            ROS_ERROR("move_base server未连接");
            return false;
        }
        
        // 将角度转换为四元数
        double yaw_rad = yaw_degrees * M_PI / 180.0;
        
        move_base_msgs::MoveBaseGoal goal;
        goal.target_pose.header.frame_id = "map";
        goal.target_pose.header.stamp = ros::Time::now();
        
        goal.target_pose.pose.position.x = x;
        goal.target_pose.pose.position.y = y;
        goal.target_pose.pose.position.z = 0.0;
        
        // 将偏航角转换为四元数
        goal.target_pose.pose.orientation.x = 0.0;
        goal.target_pose.pose.orientation.y = 0.0;
        goal.target_pose.pose.orientation.z = sin(yaw_rad / 2);
        goal.target_pose.pose.orientation.w = cos(yaw_rad / 2);
        
        ROS_INFO("开始导航至%s: x=%.2f, y=%.2f, yaw=%.1f°", goal_name.c_str(), x, y, yaw_degrees);
        
        // 创建计时器
        Timer timer;
        timer.start();
        
        // 发送目标
        ac_.sendGoal(goal);
        
        std::cout << "\n导航开始... (输入 'c' 取消)" << std::endl;
        std::cout << "==========================================" << std::endl;
        
        // 主等待循环
        bool finished = false;
        bool cancelled = false;
        ros::Rate loop_rate(10);
        
        while(!finished && ros::ok()) {
            // 检查是否完成
            finished = ac_.waitForResult(ros::Duration(0.1));
            
            // 显示进度信息
            auto state = ac_.getState();
            std::cout << "\r状态: " << state.toString() 
                      << " | 时间: " << timer.getFormattedTime() 
                      << " | 按'c'取消" << std::flush;
            
            // 检查取消（现在使用类内函数）
            if (checkForCancel()) {
                ac_.cancelGoal();
                timer.stop();
                std::cout << "\n\n导航已取消" << std::endl;
                ROS_INFO("本次导航用时: %s", timer.getFormattedTime().c_str());
                cancelled = true;
                break;
            }
            
            loop_rate.sleep();
        }
        
        std::cout << std::endl;
        
        if(finished && !cancelled) {
            timer.stop();
            if(ac_.getState() == actionlib::SimpleClientGoalState::SUCCEEDED) {
                ROS_INFO("导航完成!");
                ROS_INFO("总用时: %s", timer.getFormattedTime().c_str());
                return true;
            } else {
                ROS_WARN("导航失败: %s", ac_.getState().toString().c_str());
                ROS_INFO("用时: %s", timer.getFormattedTime().c_str());
                return false;
            }
        }
        
        return cancelled;
    }
};

// 全局函数
void setNonBlockingInput(bool nonBlocking) {
    static struct termios oldt, newt;
    
    if (nonBlocking) {
        tcgetattr(STDIN_FILENO, &oldt);
        newt = oldt;
        newt.c_lflag &= ~(ICANON | ECHO);
        tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    } else {
        tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    }
}

char getSingleCharInput() {
    struct timeval tv = {0, 0};
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    
    int ret = select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv);
    
    if (ret > 0) {
        char c;
        if (read(STDIN_FILENO, &c, 1) == 1) {
            return c;
        }
    }
    return 0;
}

int main(int argc, char** argv)
{   
    setlocale(LC_ALL,"");
    ros::init(argc, argv, "navigation_teleport_manager");
    
    NavigationManager nav_manager;
    
    // 定义预设位置
    struct Location {
        double x, y, yaw;
        std::string name;
    };
    
    std::vector<Location> locations = {
        {0.0, 0.0, 0.0, "起点"},    // 按1 - 传送
        {3.0, 4.0, 0.0, "终点"}     // 按2 - 导航
    };
    
    setNonBlockingInput(true);
    
    while(ros::ok()) {
        std::cout << "\n=== 机器人控制菜单 ===" << std::endl;
        std::cout << "1 - 传送至起点 (0, 0, 0°)" << std::endl;
        std::cout << "2 - 导航至终点 (3, 4, 0°)" << std::endl;
        std::cout << "q - 退出程序" << std::endl;
        std::cout << "请选择: ";
        
        char choice = 0;
        while(choice == 0 && ros::ok()) {
            choice = getSingleCharInput();
            ros::Duration(0.1).sleep();
        }
        
        if (choice == 'q' || choice == 'Q') {
            ROS_INFO("退出程序");
            break;
        }
        else if (choice == '1') {
            std::cout << "\n执行传送..." << std::endl;
            nav_manager.teleportToStart(locations[0].x, locations[0].y, locations[0].yaw, locations[0].name);
        }
        else if (choice == '2') {
            std::cout << "\n开始导航..." << std::endl;
            nav_manager.navigateToGoal(locations[1].x, locations[1].y, locations[1].yaw, locations[1].name);
        }
        else {
            std::cout << "\n无效选择，请重新输入" << std::endl;
        }
        
        // 短暂暂停
        ros::Duration(0.5).sleep();
    }
    
    setNonBlockingInput(false);
    return 0;
}