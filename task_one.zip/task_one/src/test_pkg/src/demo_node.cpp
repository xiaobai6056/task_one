#include <ros/ros.h>
#include <std_msgs/String.h>
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    setlocale(LC_ALL,"");
    ros::init(argc, argv, "interactive_vision_simulator");
    ros::NodeHandle nh;
    
    // 初始化发布器
    ros::Publisher qr_pub = nh.advertise<std_msgs::String>("/demo/qr_result", 1);
    ros::Publisher object_pub = nh.advertise<std_msgs::String>("/demo/object_result", 1);
    ros::Publisher simulation_pub = nh.advertise<std_msgs::String>("/demo/simulation_result", 1);
    ros::Publisher traffic_pub = nh.advertise<std_msgs::String>("/demo/traffic_result", 1);
    
    ROS_INFO("交互式视觉模拟器启动");
    ROS_INFO("命令列表:");
    ROS_INFO("  1 - 发送二维码识别结果");
    ROS_INFO("  2 - 发送物体识别结果"); 
    ROS_INFO("  3 - 发送仿真任务结果");
    ROS_INFO("  4 - 发送路牌识别结果");
    ROS_INFO("  q - 退出程序");
    
    std::string input;
    
    while (ros::ok()) {
        std::cout << "\n请输入命令 (1/2/3/4/q): ";
        std::getline(std::cin, input);
        
        if (input == "q" || input == "Q") {
            ROS_INFO("退出程序");
            break;
        }
        else if (input == "1") {
            std_msgs::String msg;
            msg.data = "水果";
            qr_pub.publish(msg);
            ROS_INFO("已发送二维码识别结果: %s", msg.data.c_str());
        }
        else if (input == "2") {
            std_msgs::String msg;
            msg.data = "苹果";
            object_pub.publish(msg);
            ROS_INFO("已发送物体识别结果: %s", msg.data.c_str());
        }
        else if (input == "3") {
            std_msgs::String msg;
            msg.data = "已完成";
            simulation_pub.publish(msg);
            ROS_INFO("已发送仿真任务结果: %s", msg.data.c_str());
        }
           else if (input == "4") {
            std_msgs::String msg;
            msg.data = "A";
            traffic_pub.publish(msg);
            ROS_INFO("已发送路牌识别结果: %s", msg.data.c_str());
        }
        else {
            ROS_WARN("无效命令，请重新输入");
        }
        
        ros::spinOnce();
    }
    
    return 0;
}